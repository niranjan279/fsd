function Search(){

    return(
      <div className="searchbar">
        <input type="text" placeholder="Search"/>
      </div>
    )
  }
  export default Search