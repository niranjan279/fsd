
import Navbar from "./components/Navbar";
import Search from "./components/Search";
import Products from "./components/Products";
import Footer from "./components/Footer";
import About from "./components/About";


function App() {
return (
  <div className="App">
    <Navbar></Navbar>
   <Search></Search>
   <Products></Products>
   <About></About>
   <Footer></Footer>
  </div>
);
}
export default App;