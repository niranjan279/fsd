import { useState } from 'react';

function Todo() {
  const [newActivity, setNewActivity] = useState('');
  const [activities, setActivities] = useState([]);

  const handleAddActivity = () => {
    if (newActivity.trim() !== '') {
      setActivities([...activities, newActivity]);
      setNewActivity('');
    }
  };

  const handleDeleteActivity = (index) => {
    setActivities(activities.filter((activity, i) => i !== index));
  };

  return (
    <div style={{
      display: 'flex', 
      flexDirection: 'column', 
      justifyContent: 'center', 
      gap: '10px', 
      width: '90vw', 
      padding: '20px',
      margin: '0 auto'
    }}>
      <h1 style={{fontFamily: 'Comic Sans MS', fontSize: '2em', marginBottom: '5px'}}>Manage activities</h1>
      
      <div>
        <input 
          placeholder="Next Activity?" 
          type="text" 
          value={newActivity}
          onChange={(e) => setNewActivity(e.target.value)}
          style={{ padding: '10px', borderRadius: '4px', border: '1px solid #ccc' }}/>
        <button 
          style={{ margin:'0px', padding: '5.5px', borderRadius: '6px', border: '1px solid #ccc', backgroundColor: '#4CAF50', color: 'white', fontSize: '1.2em' }} 
          onClick={handleAddActivity}>Add</button>
      </div>

      <ul>
        {activities.map((activity, index) => (
          <li key={index} style={{
            display: 'flex', 
            justifyContent: 'space-between', 
            padding: '10px', 
            borderRadius: '4px', 
            border: '1px solid #ccc', 
            marginBottom: '10px', 
            backgroundColor: 'rgba(138, 23, 209, 0.7)'
          }}>
            <span style={{fontSize: '1.2em', fontWeight: 'bold'}}>
              {index + 1}. {activity}
            </span>
            <button 
              style={{ 
                margin:'0px', 
                padding: '5.5px', 
                borderRadius: '6px', 
                border: '1px solid #ccc', 
                backgroundColor: 'rgba(184, 28, 17, 0.7)', 
                color: 'white', 
                fontSize: '1.2em' 
              }} 
              onClick={() => handleDeleteActivity(index)}>Delete</button>
          </li>
        ))}
      </ul>

    </div>
  )
}
export default Todo