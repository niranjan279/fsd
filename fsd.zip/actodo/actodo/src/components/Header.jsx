function Header() {
  return (
    <>
      <h1 style={{ fontFamily: 'Comic Sans MS', fontSize: '2.5em' }}>Hello John</h1>
      <p>I help you manage your activities</p>
    </>
  );
}

export default Header