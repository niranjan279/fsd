import Header from './components/Header'; 
import './App.css';
import Todo from './components/Todo';

function App() {
  return (
     <div className="div1">
      <div className="div2">
       <Header></Header>

<div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' }}>
       <div className="temp" style={{backgroundColor: 'rgba(230, 190, 255, 0.7)'}}>
        <h1>29</h1>
        <p>Singapore</p>
       </div>
       <div className="date" style={{backgroundColor: 'rgba(255, 204, 128, 0.7)'}}>
        <h1>{new Date().toLocaleDateString()}</h1>
        <p>{new Date().toLocaleTimeString()}</p>
       </div>
       <div className="built" style={{backgroundColor: 'rgba(135, 206, 235, 0.7)'}}>
        <h1>React</h1>
        <p>Built using React</p>
       </div>
</div>
<Todo></Todo>

      </div>
     </div>
  );
}

export default App;
