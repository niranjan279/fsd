import React from 'react';
import { Link } from "react-router-dom";

const Landing = () => {
  return (
    <div className="landing">
      <h1>Welcome to My App</h1>
      <p>
        This is a simple app that allows users to sign up and log in.
      </p>
      <p>
        <Link to="/Login">Log in</Link> or <Link to="/Signup">Sign up</Link> to get started.
      </p>
    </div>
  );
}

export default Landing;
