function Landing(){
    const username = localStorage.getItem('username');
    const redirectToExternal =()=>{
        window.location.href="https://actodoreactapp123.surge.sh/"
    }
    return(
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', transform: 'scale(3)', marginTop: '100px' }}>
            <h1>Click to go to the app</h1>
            <button style={{ padding: '10px 20px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }} onClick={redirectToExternal}>Click</button>
        </div>
    )
}
export default Landing