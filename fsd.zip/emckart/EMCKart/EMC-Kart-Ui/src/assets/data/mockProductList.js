export const mockProductList = [
    {
        "title": "TestProduct",
        "description": "Product",
        "price": "20",
        "image_path": "images/6k29o-laptop.jpg",
        "createdAt": "2023-11-27T16:43:27.346Z",
        "updatedAt": "2023-11-27T16:43:27.346Z",
        "id": "6564c72f778b1937f0dc51cb"
    },
    {
        "title": "Cutting Board",
        "description": "Exclusive",
        "price": "25",
        "image_path": "images/sbzfy-cover.jpg",
        "createdAt": "2023-12-22T17:09:00.726Z",
        "updatedAt": "2023-12-22T17:09:00.726Z",
        "id": "6585c2ace44b4dd6c0a9fe9f"
    },
    {
        "title": "New Product",
        "description": "test",
        "price": "14",
        "image_path": "images/9sfnr-hr.png",
        "createdAt": "2023-12-22T17:36:10.994Z",
        "updatedAt": "2023-12-22T17:36:10.994Z",
        "id": "6585c90ae44b4dd6c0a9fea1"
    },
    {
        "title": "test2",
        "description": "22",
        "price": "2",
        "image_path": "images/lwur7-hr.png",
        "createdAt": "2023-12-22T17:49:42.988Z",
        "updatedAt": "2023-12-22T17:49:42.988Z",
        "id": "6585cc36e44b4dd6c0a9fea3"
    },
    {
        "title": "test4",
        "description": "testingg",
        "price": "45",
        "image_path": "images/h8nhn-Screenshot 2023-11-24 220849.png",
        "createdAt": "2023-12-24T06:02:51.551Z",
        "updatedAt": "2023-12-24T06:02:51.551Z",
        "id": "6587c98b1eef7d2d3b70f778"
    }
];