// src/pages/ProductDemo.jsx
import React from 'react';
import { Link } from 'react-router-dom';

const ProductDemo = () => {
  const demoProducts = [
    {
      id: 1,
      name: 'Car',
      description: 'This is a Car',
      imageUrl: 'https://banner2.cleanpng.com/lnd/20240502/ler/aa2hnts4i.webp',
    },
    {
      id: 2,
      name: 'Cat',
      description: 'This is a Cat',
      imageUrl: 'https://banner2.cleanpng.com/cb3/cds/dgz/as97b2sir.webp',
    },
    {
      id: 3,
      name: 'Modern Smartphone',
      description: 'Modern Smartphone with Colorful Display PNG image is ready for your design',
      imageUrl: 'https://banner2.cleanpng.com/20180330/yye/avif6njfz.webp',
    },
];


  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
      <h1 className="text-4xl font-bold mb-6 text-gray-800">Welcome to Product Demo</h1>
      <p className="text-lg text-gray-600 max-w-xl text-center mb-8">
        Explore our demo products! Sign in to unlock more features and view the full catalog.
      </p>

      {/* Demo Products */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
        {demoProducts.map((product) => (
          <div key={product.id} className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition">
            <img src={product.imageUrl} alt={product.name}   className="object-contain border border-gray-200" 
            style={{ transform: 'scale(0.75)' }}
            />
            <div className="p-4">
              <h3 className="text-xl font-semibold text-gray-800">{product.name}</h3>
              <p className="text-gray-600 mt-2">{product.description}</p>
             
            </div>
          </div>
        ))}
      </div>

      {/* Sign-in Prompt */}
      <Link to="/login">
        <button className="bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700 transition">
          Sign In to Continue
        </button>
      </Link>
    </div>
  );
};

export default ProductDemo;
