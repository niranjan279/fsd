import { useState } from "react";
function Todo(){
    const[list,setlist]= useState([
        {id:1,activity:"apple"},
        {id:2,activity:"banana"},
        {id:3,activity:"cherry"},
        {id:4,activity:"dragon fruit"},
        {id:5,activity:"elderberry"},
        {id:6,activity:"fig"},
        {id:7,activity:"grape"},
        {id:8,activity:"honeydew"}
    ]);
    const [newitem,setnewitem]= useState("");
    function handleDelete(removeid){
        var temp=list.filter(function(item){
          if(item.id==removeid){
            return false
          }  
          else{
            return true
          } 
        })
        setlist(temp)

    }
    function handleChange(){
        var temp={id:list.length+1,activity:newitem}
        var temp1=list.concat(temp)
        setlist(temp1)
    }
    return(
        <>
        <h1>Todo List</h1>
        <input value={newitem} onChange={(e) => setnewitem(e.target.value)}></input>
        <button onClick={() => { handleChange(); setnewitem(""); }}>add</button>
        <ul>
            {list.map((item) => (
              <li>
                {item.activity}
                <button onClick={() => handleDelete(item.id)}>delete</button>
              </li>
            ))}
        </ul>
        </>
    );
}
export default Todo