// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCQvJrS6-eLZXX_DkvoZRF7yo8NadpvGBw",
  authDomain: "blogapp-14ede.firebaseapp.com",
  projectId: "blogapp-14ede",
  storageBucket: "blogapp-14ede.firebasestorage.app",
  messagingSenderId: "248306412219",
  appId: "1:248306412219:web:cf1596150cbe50e688d79e",
  measurementId: "G-KTJ4SCYMCG"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth= getAuth(app);
const analytics = getAnalytics(app);
export default auth;