sudo mongod & 
cd blog-project-starter-frontend/ && npm start &
node /home/cdlen/Downloads/fsd/blog/blog-project-starter-backend/index.js &





wait
