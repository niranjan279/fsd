import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";
function App() {
  const [enteredvalue, setEnteredValue] = useState("");
  const [fruit,setfruit]=useState([])

  useEffect(function(){
    axios.get("https://backendtest-a7i4.onrender.com/fruitlist").then(function(data){
      setfruit(data.data)
    })
  },[])
  
  function handlevalue(evt) {
    setEnteredValue(evt.target.value);
  }
  function add(){
    axios.post("https://backendtest-a7i4.onrender.com/addfruit",{fruit:enteredvalue})
    
    setfruit([...fruit,enteredvalue])
    setEnteredValue("")
  }
  return (
    <div className="App">
      <button onClick={add}>add</button>
    <input onChange={handlevalue}></input>
    {fruit.map(function(item,index){
      return <h1 key={index}>{item}</h1>})}
    </div>
  );
}

export default App;
