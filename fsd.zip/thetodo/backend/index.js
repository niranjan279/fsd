const express =require("express")
const cors = require("cors")

const app= express()
app.use(cors())
app.use(express.json())
const fruit = []
app.get("/fruitlist",function(req,res){
    res.send(fruit)
})
app.post("/addfruit",function(req,res){
    fruit.push(req.body.fruit)
    res.send("fruit added")
})
app.listen(5000,()=>console.log("server is running on port 5000"))