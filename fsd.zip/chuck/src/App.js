import { useState } from 'react';
import './App.css';
import axios from 'axios';

function App() {
  const [category,setCategory] = useState();
  const [joke,setJoke] = useState();
  function handleChangeCategory(e){
    setCategory(e.target.value);
    
  }
  function fetchJokes(){
    axios.get(`https://api.chucknorris.io/jokes/random?category=${category}`).then(function(result){
      console.log(result.data.value);
      setJoke(result.data.value);
    })
  }
  return (
    <div className="App">
      <input onChange={handleChangeCategory}></input>
      <button onClick={fetchJokes}>Get Joke</button>
      <h1>{joke}</h1>
      <h1 style={{fontSize: "15px"}}>Available categories are "animal","career","celebrity","dev","explicit","fashion","food","history","money","movie","music","political","religion","science","sport","travel"</h1>
    </div>
  );
}

export default App;
