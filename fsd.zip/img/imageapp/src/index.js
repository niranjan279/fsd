import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import dog from './img/dog.jpg';
import dog2 from './img/dog2.jpg';
import dog3 from './img/dog3.jpg';
import untitled from './img/Untitled.jpg';





const ImageGallery = () => {

const images = [
  { id: 1, url: dog3 },
  { id: 2, url: untitled },
  { id: 3, url: dog },
  { id: 4, url: dog2 },
  { id: 5, url: dog2 },
  { id: 6, url: dog3 },
  { id: 7, url: untitled },
  { id: 8, url: dog }
];

const galleryStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gridTemplateRows: "repeat(2, auto)",
  gap: "10px",
  padding: "20px",
  justifyContent: "center",
  alignItems: "center",
  backgroundColor: "#f8f9fa",
};

const itemStyle = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  backgroundColor: "#e0e0e0",
  padding: "10px",
  borderRadius: "8px",
  boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
};

const imgStyle = {
  width: "90%",
  height: "150px",
  objectFit: "cover",
  borderRadius: "6px",
};

const textStyle = {
  textAlign: "center",
  marginTop: "8px",
  fontWeight: "bold",
  color: "#333",
};

return (
  <div style={galleryStyle}>
    {images.map((image) => (
      <div key={image.id} style={itemStyle}>
        <img src={image.url} alt={`Image ${image.id}`} style={imgStyle} />
        <p style={textStyle}>{`Image ${image.id}`}</p>
      </div>
    ))}
  </div>
);

};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ImageGallery/>
  </React.StrictMode>
);
