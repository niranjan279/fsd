import React, { useState } from "react";
import ReactDOM from "react-dom/client";

function RandomNumberGenerator() {
  const [number, setNumber] = useState(Math.floor(Math.random() * 100) + 1);

  const generateRandomNumber = () => {
    setNumber(Math.floor(Math.random() * 100) + 1);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h1>{number}</h1>
      <button onClick={generateRandomNumber} style={{ padding: "10px 20px", fontSize: "16px", cursor: "pointer" }}>
        Generate Random Number
      </button>
    </div>
  ); 
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RandomNumberGenerator />);
