import { useState } from "react"
function List(){

    const [checked,setchecked] = useState(false)
    const handlechange=()=>{
        setchecked(!checked)
    }
    
return(
    <div>
        <h1>List of Activties </h1>
        <div>
            <input onChange={handlechange} type="checkbox"></input>
            <span style={{textDecoration:checked?"line-through":"none"}}>Wake up at 6:30</span>
        </div>
    </div>
    )
}


export default List