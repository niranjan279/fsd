import { useState } from "react"
function Login(){
    const [login,setlogin]=useState(false)
    const [uname,setname]=useState("")
    const [pass,setpass]=useState("")
    const handlelogin=()=>{
        var username="john"
        var password="123"
       
        if(username == uname && password == pass){
            setlogin(true)
            console.log("success")
        }
    }
    const handleuname=(evt)=>{
        setname(evt.target.value)
    }
    const handlepass=(evt)=>{
        setpass(evt.target.value)
    }

    return(
        <div>
            <h1>login page</h1>
            {
                login?<h1>success</h1>:  <div>
                <input value={uname} onChange={handleuname} placeholder="username"></input><br></br>
                <input value={pass} onChange={handlepass}placeholder="password"></input><br/>
                <button onClick={handlelogin}>login</button>
                </div>
               
            }
            </div>
            
            
    )
}


export default Login