import { useState } from "react";

const ShoppingList=()=>{
    const [mylist,setmylist] = useState(['Tomato', 'Carrot', 'Cucumber', 'Potato']);
    const [item,setItem] = useState("")

    const handleChange=(evt)=>{
        setItem(evt.target.value)
    }
    const handleAdd=()=>{
        setmylist([...mylist,item])
        setItem('')
    }
    return(
        
        <div>
        
                <input value={item} onChange={handleChange} type="text" placeholder="Enter Item" />
                <button onClick={handleAdd}type="submit">Add</button>
        <ul>
           {mylist.map(function(item){
            return <li>{item}</li>
           })}
        </ul>
           

        </div>)
}
export default ShoppingList