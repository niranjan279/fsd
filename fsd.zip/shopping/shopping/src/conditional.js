import { useState } from "react"
function Colorchange(){
    const [colorst,setcolorst]= useState(false)
    function handleChange(){
        setcolorst(!colorst)
    }
    return(
        <div>
            <div style={{width: "100px", height: "100px", backgroundColor:colorst?"red":"green"}}></div>
            <button onClick={handleChange}>Change Color</button>
        </div>
    )
}
export default Colorchange
{/* <div style={{width: "100px", height: "100px", backgroundColor: "red"}}></div>
            <button onClick={() => {
                const randomHex = Math.floor(Math.random()*16777215).toString(16);
                document.querySelector("div[style]").style.backgroundColor = `#${randomHex}`;
            }}>Change Color</button> */}