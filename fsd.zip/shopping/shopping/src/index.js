import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import ShoppingList from './ShoppingList';
import Colorchange from './conditional';
import List from './list';
import Login from './login';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<div>
  <button onClick={() => root.render(<ShoppingList />)}>Render Shopping List</button>
  <button onClick={() => root.render(<Colorchange />)}>Render Colorchange</button>
  <button onClick={() => root.render(<List />)}>List</button>
  <button onClick={() => root.render(<Login/>)}>Login</button>
</div>

);
